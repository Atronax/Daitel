#include <stdio.h>

main()
{
	float pi, radius, diameter, perimeter, space;

	pi = 3.14159;
	printf("Input radius of circle: ");
	scanf("%f", &radius);

	printf("\n\nPerimeter of circle is %f\n", 2*pi*radius);
	printf("Space of circle if %f\n", pi*radius*radius);
	printf("Diameter of circle is %f\n", 2*radius);
}
