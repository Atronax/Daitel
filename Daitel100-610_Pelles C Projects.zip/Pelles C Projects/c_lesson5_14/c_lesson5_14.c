#include <stdio.h>
#include <locale.h>

int main(void)
{
	setlocale(LC_ALL,"");

	int counter1, counter2;

	counter1 = 2;

	while (counter1 <= 9)
		{
		counter2 = 1;
		while (counter2 <= 8)
			{
			counter2++;
			printf("* ");
			}
		
		printf("\n");
		if (counter1 % 2 == 0)
			printf(" ");
		counter1++;		
		}
	printf("\n\n");
}
