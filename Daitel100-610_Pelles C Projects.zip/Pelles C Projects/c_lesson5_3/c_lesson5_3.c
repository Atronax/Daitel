#include <stdio.h>
#include <locale.h>

int main(void)
{
	setlocale(LC_ALL,"");

	int n;

	n = 1;

	printf("N\t10*N\t100*N\t1000*N\n\n");

	while (n <= 10)
		{
		printf("%d\t%d\t%d\t%d\n", n, 10*n, 100*n, 1000*n);
		n++;
		}
}
