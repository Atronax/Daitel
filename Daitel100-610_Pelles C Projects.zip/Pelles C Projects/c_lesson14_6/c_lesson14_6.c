#include <stdio.h>
#include <locale.h>

float fahrcels (float);
float celsfahr (float);
float fahrkelv (float);
float celskelv (float);
float kelvfahr (float);
float kelvcels (float);

float fahrcels (float fahrenheit)
{
	return (fahrenheit - 32)*5/9;
}

float celsfahr (float celsius)
{
	return (celsius*9/5) + 32;
}

float fahrkelv (float fahrenheit)
{
	return ((fahrenheit - 32)*5/9) - 273;
}

float celskelv (float celsius)
{
	return celsius - 273;
}

float kelvcels (float kelvin)
{
	return kelvin + 273;
}

float kelvfahr (float kelvin)
{
	return ((kelvin + 273)*9/5) + 32;
}

int main(void)
{
	setlocale(LC_ALL,"");

	float celsius, fahrenheit;

	printf("%8s - %9s - %8s\n\n", "�������", "���������", "�������");
	for (celsius = 1700; celsius <= 2000; celsius++)
		printf("%8.2f - %9.2f - %8.2f\n", celsius, celsfahr(celsius), celskelv(celsius));
}
