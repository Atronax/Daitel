#include <stdio.h>
#include <locale.h>

int main (int count)
{
	count = 1;
	count--;
	printf("%d", count);
	return main(count);
}
