#include <stdio.h>
#include <locale.h>

int main(void)
{
	setlocale(LC_ALL,"");

	int number, a, a1, b, b1, c, c1, d, d1, temp1, temp2, temp3, temp4;

	printf("������� �������������� �����: ");
	scanf("%d", &number);

	a = (number / 1000) % 10;
	b = (number / 100) % 10;
	c = (number / 10) % 10;
	d = number % 10;
		a1 = (a + 7) % 10;
		b1 = (b + 7) % 10;
		c1 = (c + 7) % 10;
		d1 = (d + 7) % 10;
	temp1 = a1;
	temp2 = b1;
	temp3 = c1;
	temp4 = d1;
		a1 = temp3;
		b1 = temp4;
		c1 = temp1;
		d1 = temp2;

	printf("%d%d%d%d\n", a1, b1, c1, d1);
}
