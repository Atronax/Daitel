#include <stdio.h>
#include <locale.h>

int main(void)
{
	setlocale(LC_ALL,"");

	int number, a, a1, b, b1, c, c1, d, d1, temp1, temp2, temp3, temp4;

	printf("������� �������������� �����: ");
	scanf("%d", &number);

	a1 = (number / 1000) % 10;
	b1 = (number / 100) % 10;
	c1 = (number / 10) % 10;
	d1 = number % 10;
		temp1 = a1;
		temp2 = b1;
		temp3 = c1;
		temp4 = d1;
	a = temp3;
	b = temp4;
	c = temp1;
	d = temp2;
		a += 3;
		b += 3;
		c += 3;
		d += 3;

	printf("%d%d%d%d\n", a, b, c, d);

	
}
