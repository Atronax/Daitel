#include <stdio.h>
#include <locale.h>
#define SIZE 20

int main (void)
{
	setlocale(LC_ALL,"");

	int array[SIZE]={7, 12, 15, 11, 45, 32, 144, 143, 112, 121, 125, 148, 160, 185, 170, 192, 172, 183, 200, 204};
	int temp, pass, i;

	for (i = 0; i <= SIZE - 1; i++)
		printf("%4d", array[i]);

	for (pass = 1; pass <= SIZE - 1; pass++)
		{
		for (i = 0; i <= SIZE - 1; i++)
			{
			if (array[i] > array[i + 1])
				{
				temp = array[i + 1];
				array[i + 1] = array[i];
				array[i] = temp;
				}
			}
		}

	printf("\n\n");

	for (i = 0; i <= SIZE - 1; i++)
		printf("%4d", array[i]);

	printf("\n\n");
}
