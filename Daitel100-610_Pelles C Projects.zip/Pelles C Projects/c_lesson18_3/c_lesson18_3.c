#include <stdio.h>
#include <locale.h>

void print_array (int array[][4])
{
	int i, j;

	for (i = 0; i <= 1; i++)
		{
		for (j = 0; j <= 3; j++)
			printf("%d", array[i][j]);

		printf("\n");
		}
	printf("\n");
}

int main (void)
{
	setlocale(LC_ALL,"");

	int array_1[2][4] = {{1, 2, 3, 4},{5, 6, 7, 8}};
	int array_2[2][4] = {2, 4, 6, 8, 6, 6};
	int array_3[2][4] = {{1, 2}, {0, 1, 2}};

	print_array (array_1);
	print_array (array_2);
	print_array (array_3);
}
