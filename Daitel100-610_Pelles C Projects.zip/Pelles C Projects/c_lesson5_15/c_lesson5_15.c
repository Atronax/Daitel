#include <stdio.h>
#include <locale.h>

int main(void)
{
	setlocale(LC_ALL,"");

	int a, b, n;

	a = 2;
	n = 3;

	while (a > 0)
		{
		b = 2 * a;
		printf("%d - %d\n", n, b);
		a *= 2;
		n++;
		}
	printf("\n\n");
}
