#include <stdio.h>

main()
{
	printf(" *********\t\t   ***   \t\t    *    \t\t    *    ");
	printf("*       *\t\t *     * \t\t   ***   \t\t   * *   ");
	printf("*       *\t\t*       *\t\t  *****  \t\t  *   *  ");
	printf("*       *\t\t*       *\t\t    *    \t\t *     * ");
	printf("*       *\t\t*       *\t\t    *    \t\t*       *");
	printf("*       *\t\t*       *\t\t    *    \t\t *     * ");
	printf("*       *\t\t*       *\t\t    *    \t\t  *   *  ");
	printf("*       *\t\t *     * \t\t    *    \t\t   * *   ");
	printf("*********\t\t   ***   \t\t    *    \t\t    *    ");
}
