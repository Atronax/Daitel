#include <stdio.h>
#include <locale.h>

int main(void)
{
	setlocale(LC_ALL,"");

	int a;

	a = 3;

	printf("A\tA+2\tA+4\tA+6\n\n");

	while (a <= 15)
		{
		printf("%d\t%d\t%d\t%d\n", a, a+2, a+4, a+6);
		a += 3;
		}
}
