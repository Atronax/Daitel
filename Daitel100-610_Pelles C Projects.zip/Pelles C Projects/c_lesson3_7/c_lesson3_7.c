#include <stdio.h>

main()
{
	printf(" 3333  \t\t   MM     MM   \t\t   MM     MM   \n");
	printf("33  33 \t\t   M M   M M   \t\t   M M   M M   \n");
	printf("      3\t\t   M M   M M   \t\t   M M   M M   \n");
	printf("    33 \t\t  MM  M M  MM  \t\t  MM  M M  MM  \n");
	printf("  333  \t\t  M    M    M  \t\t  M    M    M  \n");
	printf("    33 \t\t  M         M  \t\t  M         M  \n");
	printf("      3\t\t  M         M  \t\t  M         M  \n");
	printf("33  33 \t\t MM         MM \t\t MM         MM \n");
	printf(" 3333  \t\tMMM         MMM\t\tMMM         MMM\n");
}
