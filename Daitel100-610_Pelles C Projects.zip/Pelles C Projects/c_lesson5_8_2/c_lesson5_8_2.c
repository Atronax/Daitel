#include <stdio.h>

int main () 
{
  int a = 0;
  int i = 0;

  printf ("Please input side a>");
  scanf ("%d", &a);

  while(++i <= a) 
	{
    	int j = 0;
   			while (++j <= a) 
      		putchar((i == 1 || j == 1 || i == a || j == a) ? '*' : ' ');
    	putchar('\n');
 	 }
  return 0;
}
