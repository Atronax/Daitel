#include <stdio.h>

main()
{
	int a, b, c, d, e;
	
	printf("Input 5 numbers: ");
	scanf("%d%d%d%d%d", &a,&b,&c,&d,&e);

	if (a<b)
		if (a<c)
			if (a<d)
				if (a<e)
					printf("%d is smallest\n", a);
	if (b<a)
		if (b<c)
			if (b<d)
				if (b<e)
					printf("%d is smallest\n", b);
	if (c<a)
		if (c<b)
			if (c<d)
				if (c<e)
					printf("%d is smallest\n", c);
	if (d<a)
		if (d<b)
			if (d<c)
				if (d<e)
					printf("%d is smallest\n", d);
	if (e<a)
		if (e<b)
			if (e<c)
				if (e<d)
					printf("%d is smallest\n", e);

	if (a>b)
		if (a>c)
			if (a>d)
				if (a>e)
					printf("%d is largest\n", a);
	if (b>a)
		if (b>c)
			if (b>d)
				if (b>e)
					printf("%d is largest\n", b);
	if (c>a)
		if (c>b)
			if (c>d)
				if (c>e)
					printf("%d is largest\n", c);
	if (d>a)
		if (d>b)
			if (d>c)
				if (d>e)
					printf("%d is largest\n", d);
	if (e>a)
		if (e>b)
			if (e>c)
				if (e>d)
					printf("%d is largest\n", e);

}
