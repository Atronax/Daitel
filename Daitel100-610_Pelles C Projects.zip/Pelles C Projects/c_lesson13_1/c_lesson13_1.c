#include <stdio.h>
#include <math.h>
#include <locale.h>

int main(void)
{
	setlocale(LC_ALL,"");

	printf("%.2f\n", sqrt(900));
	printf("%.2f\n", exp(1));
	printf("%.2f\n", log(2.718282));
	printf("%.2f\n", log10(1));
	printf("%.2f\n", fabs(-5));
	printf("%.2f\n", ceil(9.245));
	printf("%.2f\n", floor(9.245));
	printf("%.2f\n", pow(2,3));
	printf("%.2f\n", fmod(7.543,5.324));
	printf("%.2f\n", sin(0));
	printf("%.2f\n", cos(0));
	printf("%.2f\n", tan(0));
}
