#include <stdio.h>
#include <locale.h>

int simple (int);

int simple (int number)
{
	int i, sum;

	sum = 0;

	for (i = 1; i <= number; i++)
		if (number % i == 0)
			{
			printf("%d ", i);
			sum += i;
			}
	
	printf("\n");
	if (sum == number + 1)
		return 1;
	else
		return 0;
}

int main (void)
{
	setlocale(LC_ALL,"");

	int number;

	for (number = 1; number <= 999; number++)
		printf("%d - ������� ��� ��? %d\n\n", number, simple(number));
}
