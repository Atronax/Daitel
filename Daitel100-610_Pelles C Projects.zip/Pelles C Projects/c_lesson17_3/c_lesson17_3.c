#include <stdio.h>
#include <locale.h>
#define RESPONSE_SIZE 40
#define FREQUENCY_SIZE 11

int main (void)
{
	setlocale(LC_ALL,"");

	int A[RESPONSE_SIZE] = {4, 8, 10, 5, 1, 4, 6, 4, 3, 2, 1, 2, 10, 9, 8, 7, 4, 6, 9, 10, 3, 5, 5, 9, 8, 5, 9, 7, 4, 3, 4, 5, 7, 8, 9, 10, 9, 8, 9, 10};
	int i, totalsum, average, rating;
	int B[FREQUENCY_SIZE] = {0};

	totalsum = 0;

	for (i = 0; i <= RESPONSE_SIZE - 1; i++)
		totalsum += A[i];
	average = totalsum / RESPONSE_SIZE;
	printf("������� ������ �������� - %d\n\n", average);

	for (i = 0; i <= RESPONSE_SIZE - 1; i++)
		++B[A[i]];

	printf("������� - �������\n\n");
	for (rating = 1; rating <= FREQUENCY_SIZE - 1; rating++)
		printf("%7d - %7d\n", rating, B[rating]);
}
