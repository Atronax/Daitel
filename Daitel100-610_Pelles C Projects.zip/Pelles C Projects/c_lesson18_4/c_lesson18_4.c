#include <stdio.h>
#include <locale.h>
#define STUDENTS 3
#define EXAMS 4

void print_array (int [][EXAMS], int, int);
int minimum (int [][EXAMS], int, int);
int maximum (int [][EXAMS], int, int);
float average (int [], int);

void print_array (int array [][EXAMS], int pupils, int tests)
{
	int i, j;

	printf("     [0]  [1]  [2]  [3]");

	for (i = 0; i <= pupils - 1; i++)
		{
		printf("\n[%d]  ", i);

		for (j = 0; j <= tests - 1; j++)
			printf("%-5d", array [i][j]);
		}
	printf("\n");
}

int minimum (int grades [][EXAMS], int pupils, int tests)
{
	int i, j;
	int lowest_grade = 100;

	for (i = 0; i <= pupils - 1; i++)
		for (j = 0; j <= tests - 1; j++)
			if (grades[i][j] < lowest_grade)
				lowest_grade = grades[i][j];

	return lowest_grade;
}

int maximum (int grades [][EXAMS], int pupils, int tests)
{
	int i, j;
	int highest_grade = 0;

	for (i = 0; i <= pupils - 1; i++)
		for (j = 0; j <= tests - 1; j++)
			if (grades[i][j] > highest_grade)
				highest_grade = grades[i][j];

	return highest_grade;
}

float average (int set_of_grades [], int tests)
{
	int i;
	int total_sum = 0;

	for (i = 0; i <= tests - 1; i++)
		total_sum += set_of_grades [i];

	return total_sum / EXAMS;
}

int main (void)
{
	setlocale(LC_ALL,"");

	int counter;
	int student_grades[STUDENTS][EXAMS] = {{82, 77, 65, 93},{76, 78, 91, 88},{92, 67, 62, 90}};

	printf("��� ��������� ������: \n\n");
	print_array (student_grades, STUDENTS, EXAMS);

	printf("\n\n");
	printf("���������� ���� - %d.\n", minimum(student_grades, STUDENTS, EXAMS));
	printf("���������� ���� - %d.\n", maximum(student_grades, STUDENTS, EXAMS));
	printf("\n\n");

	for (counter = 0; counter <= STUDENTS - 1; counter++)
		printf("������� ���� ��� �������� [%d] - %.1f.\n", counter, average(student_grades [counter], EXAMS));

	printf("\n\n");
}
