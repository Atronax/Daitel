#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <locale.h>

int rolldice(void);

int rolldice(void)
{
	int d1, d2, sum;

	d1 = 1 + rand() % 6;
	d2 = 1 + rand() % 6;
	sum = d1 + d2;

	printf("%d + %d = %d\n", d1, d2, sum);

	return sum;
}

int main(void)
{
	srand(time(NULL));
	setlocale(LC_ALL,"");

	int totalsum, mypoint, gamestatus;

	mypoint = 0;

	totalsum = rolldice();
		switch(totalsum)
			{
			case 7: case 11:
			gamestatus = 1;
			break;

			case 2: case 3: case 12:
			gamestatus = -1;
			break;

			default:
			mypoint = totalsum;
			printf("�����: %d\n", totalsum);
			gamestatus = 0;
			break;
			}

	while (gamestatus == 0)
	{
	totalsum = rolldice();

		if (totalsum == mypoint)
			gamestatus = 1;
		if (totalsum == 7)
			gamestatus = -1;
	}

	if (gamestatus == 1)
		printf("����� �������!\n");
	if (gamestatus == -1)
		printf("������ � ��������!\n");

	printf("\n\n");
}
