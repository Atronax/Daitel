#include <stdio.h>
#include <locale.h>

int perfect (int);

int perfect (int number)
{
	int i, sum = 0;

	for (i = 1; i < number; i++)
		if (number % i == 0)
			{
			printf("%d ", i);
			sum += i;			
			}

	printf("\n");
	if (sum == number)
		return 1;
	else
		return 0;
	
}

int main (void)
{
	int number;

	setlocale(LC_ALL,"");

	for (number = 1;number <= 100; number++)
		printf("%������������ ����� %d - %d\n\n", number, perfect(number));
}
