#include <stdio.h>
#include <locale.h>

int main(void)
{
	setlocale(LC_ALL,"");

	int i, j; /*j - ���������� �� �, i - ���������� �� y*/

	for (i = 1; i <= 10; i++) /*1*/
		{
		for (j = 1; j <= 10; j++)
			if (i / j == 0 || i - j == 0)
				printf("*");
			else
				printf(" ");
		printf("\n");		
		}			

	printf("\n\n");

	for (i = 1; i <= 10; i++) /*2*/
		{
		for (j = 1; j <= 10; j++)
			if (i / j != 0 || i - j == 0)
				printf("*");
			else
				printf(" ");
		printf("\n");		
		}

	printf("\n\n");

	for (i = 1; i <= 10; i++) /*3*/
		{
		for (j = 10; j >= 1; j--)
			if (i / j == 0 || i - j == 0)
				printf("*");
			else
				printf(" ");
		printf("\n");		
		}

	printf("\n\n");

	for (i = 1; i <= 10; i++)/*4*/
		{
		for (j = 10; j >= 1; j--)
			if (i / j != 0 || i - j == 0)
				printf("*");
			else
				printf(" ");
		printf("\n");		
		}

	printf("\n\n");		
}
