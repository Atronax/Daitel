#include <stdio.h>
#include <locale.h>

int leftret (int);

int leftret (int a)
{
	int revnum = 0;

	while (a > 0)
		{
		revnum = revnum*10 + a%10;
		a /=10; 
		}

	a = revnum;

	while (a > 0)
		{
		printf("%d  ", a % 10);
		a /= 10;
		}
}

int main(void)
{
	setlocale(LC_ALL,"");

	int a;
	
	printf("������� �����: ");
	scanf("%d", &a);
	
	leftret(a);
}
