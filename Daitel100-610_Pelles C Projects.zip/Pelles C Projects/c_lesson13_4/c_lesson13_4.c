#include <stdio.h>
#include <math.h>
#include <locale.h>

double roundToInteger(float);
float roundToTenths(float);
float roundToHundreds(float);
float roundToThousands(float);

double roundToInteger(float x)
{
	return floor(x + .5);
}

float roundToTenths(float x)
{
	return (floor(10 * x + .5) / 10);
}

float roundToHundreds(float x)
{
	return (floor(100 * x + .5) / 100);
}

float roundToThousands(float x)
{
	return (floor(1000 * x + .5) / 1000);
}

main(void)
{
	setlocale(LC_ALL,"");

	float x;

	printf("������� ����� �: ");
	scanf("%f", &x);

	printf("%f - %f - %f - %f\n\n", roundToInteger(x), roundToTenths(x), roundToHundreds(x), roundToThousands(x));
}
