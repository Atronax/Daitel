#include <stdio.h>
#include <locale.h>
#define SIZE 15

void print_header (void);
int binary_search (int [], int, int, int);
void print_row (int [], int, int, int);

void print_header (void)
{
	int i;

	printf("\t����������: \n\n");
	for (i = 0; i <= SIZE - 1; i++)
		printf("%3d ", i);

	printf("\n");
	for (i = 1; i <= 4 * SIZE; i++)
		printf("_");

	printf("\n");
}

int binary_search (int array[], int search_key, int low, int high)
{
	int middle;

	while (low <= high)
		{
		middle = (low + high) / 2;

		print_row (array, low, middle, high);

		if (search_key == array[middle])
			return middle;
		else
			if (search_key > array[middle])
				low = middle + 1;
			else
				high = middle - 1;
		}

	return -1;
}

void print_row (int array[], int low, int middle, int high)
{
	int i;

	for (i = 0; i <= SIZE - 1; i++)
		if (i < low || i > high)
			printf("    ");
		else
			if (i == middle)
				printf("%3d*", array[i]);
			else
				printf("%3d ", array[i]);

	printf("\n");
}

int main (void)
{
	setlocale(LC_ALL,"");

	int search_key, result;
	int massive[SIZE] = {0}, i;

	for (i = 0; i <= SIZE - 1; i++)
		massive[i] = i * 3;

	printf("������� ���� ������: ");
	scanf("%d", &search_key);

	print_header();
	result = binary_search(massive, search_key, 0, SIZE - 1);

	if (result != -1)
		printf("���� %d ������ � %d ��������.\n", search_key, result);
	else
		printf("���� %d � ������ ������� �� ������.\n", search_key);
}
