#include <stdio.h>

main()
{
	int a;
	printf("Input integer number: ");
	scanf("%d", &a);

	if (a%2 == 0)
		printf("This number is PARNE\n");
	if (a%2 != 0)
		printf("This number is NEPARNE\n");


}
