#include <stdio.h>
main()
{
	int a,b,c;

	printf("Input three different integers: ");
	scanf("%d%d%d", &a,&b,&c);

	printf("\nSum is %d", a+b+c);
	printf("\nAverage is %d", (a+b+c)/3);
	printf("\nProduct is %d\n", a*b*c);

	if (a < b)
		if (a < c)
			printf("%d is smallest\n", a);
	if (b < a)
		if (b < c)
			printf("%d is smallest\n", b);
	if (c < a)
		if (c < b)
			printf("%d is smallest\n", c);

	if (a > b)
		if (a > c)
			printf("%d is largest\n", a);
	if (b > a)
		if (b > c)
			printf("%d is largest\n", b);
	if (c > a)
		if (c > b)
			printf("%d is largest\n", c);

}
