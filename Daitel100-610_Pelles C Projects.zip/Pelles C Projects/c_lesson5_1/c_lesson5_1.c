#include <stdio.h>
#include <locale.h>

int main(void)
{
	setlocale(LC_ALL,"");

	int i;

	i = 0;

	while (i <= 100)
		{
		printf("%d ", i);
		i++;
		printf("\n");
		}
}
