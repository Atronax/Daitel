#include <stdio.h>
#include <locale.h>
#define SIZE 18

int main (void)
{
	setlocale(LC_ALL,"");

	int table[SIZE][SIZE];
	int x, y;

	for (x = 0; x <= SIZE - 1; x++)
		for (y = 0; y <= SIZE - 1; y++)
			table[x][y] = x * y;

	printf("������� ���������: \n\n");
	
	printf(" x");
	for (x = 0; x <= SIZE - 1; x++)
		printf("%3d ", x);
	printf("\n\n");

	for (x = 0; x <= SIZE - 1; x++)
		{
		printf("%2d", x);

		for (y = 0; y <= SIZE - 1; y++)
			printf("%3d ", table[x][y]);
		printf("\n");
		}
}
