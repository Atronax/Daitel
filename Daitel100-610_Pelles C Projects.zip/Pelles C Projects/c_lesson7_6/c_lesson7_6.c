#include <stdio.h>
#include <locale.h>

int main(void)
{
	setlocale(LC_ALL,"");

	int a, n;

	a = 1;

	printf("�����\t\t#######\t\t���������\n\n");

	for (n = 1; n <= 12; n++)
		{
		if (n == 0 || n == 1)
			a = 1;
		else
			a *= n;
		printf("%d\t\t#######\t\t%10d\n", n, a);
		}
}
