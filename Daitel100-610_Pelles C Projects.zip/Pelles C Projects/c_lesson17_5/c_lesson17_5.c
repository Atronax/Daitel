#include <stdio.h>
#include <locale.h>
#include <time.h>
#define SIZE 7

int main (void)
{
	srand(time(NULL));
	setlocale(LC_ALL,"");

	int frequency[SIZE] = {0};
	int face, roll, i;

	for (roll = 1; roll <= 6000; roll++)
		{
		face = 1+ rand() % 6;

		++frequency[face];
		}

	printf("������ | �������\n\n");
	for (i = 1; i <= 6; i++)
		printf("%6d | %7d\n", i , frequency[i]);
}
