#include <stdio.h>
#include <locale.h>

main(void)
{
	srand(time(NULL));
	int n1, n2, n3;

	n1 = 2 + 2*(rand() % 5);
	n2 = 3 + 2*(rand() % 5);
	n3 = 6 + 4*(rand() % 5);

	printf("%d - %d - %d\n", n1, n2, n3);
}
