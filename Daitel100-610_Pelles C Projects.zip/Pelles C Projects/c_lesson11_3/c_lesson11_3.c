#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main(void)
{
	setlocale(LC_ALL,"");
	srand((unsigned)time(NULL));

	int i;
	
	for (i = 1; i <= 2; i++)
		{
		printf("%d\n", 1 + (rand() % 6));
		if (i % 5 == 0)
			printf("\n");
		}

	printf("\n\n");
	system("pause");
}
