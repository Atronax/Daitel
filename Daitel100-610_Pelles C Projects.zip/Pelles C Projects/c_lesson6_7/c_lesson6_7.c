#include <stdio.h>
#include <locale.h>
#include <math.h>

int main(void)
{
	setlocale(LC_ALL,"");

	int sum, count, x;

	sum = 0;
	x = 1;
	count = 1;

	for (count = 1; count < 100; count +=2)
		sum += count;

	printf("����� �������� ����� �� 1 �� 100 - %d\n\n", sum);

	printf("%-15.1f\n", 333.546372);
	printf("%-15.2f\n", 333.546372);
	printf("%-15.3f\n", 333.546372);
	printf("%-15.4f\n", 333.546372);
	printf("%-15.5f\n\n", 333.546372);

	printf("%-10.2f\n\n", pow(2.5,3));

	while (x <= 20)
		{
			if (x % 5 == 0)
				printf("%d\n", x);
			else
				printf("\t");
		x++;
		}

	for (x = 1; x <= 20; x++)
		if (x % 5 == 0)
			printf("%d\n", x);
		else
			printf("\t");
}
