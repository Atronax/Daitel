#include <stdio.h>

main()
{
	float a;

	printf("Input desired number: ");
	scanf("%f", &a);

	printf("Square is %f\n", a*a);
	printf("Cube is %f\n", a*a*a);
}
