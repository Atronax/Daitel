#include <stdio.h>

int main(void)
{
	int x, y, a, b, i, j, g;

	if ((!(x < 5) && !(y >= 7)) == !(x < 5 || y >= 7))
		printf("True\n\n");
	else
		printf("False\n\n");

	if (!(a == b) || !(g != 5) == !(a == b && g != 5))
		printf("True\n\n");
	else
		printf("False\n\n");

	if (!(x < 8) && !(y > 4) == !(x <= 8) || !(y > 4))
		printf("True\n\n");
	else
		printf("False\n\n");

	if ((!(i > 4) && !(j <= 6)) == (!(i > 4) && !(j <= 6)))
		printf("True\n\n");
	else
		printf("False\n\n");
}
