// Tic-Tac-Toe. Plays the game of tic-tac-toe against a human opponent.

#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;

// CONSTANTS
const char X = 'X';
const char O = '0';
const char EMPTY = ' ';
const char TIE = 'T';
const char NO_ONE = 'N';

// PROTOTYPES
void show_instructions();
char ask (string question);
int    ask (string question, int low, int high);
char humans_piece();
char opponents_piece(char piece);
void display_board (const vector<char>& board);
char winner (const vector<char>& board);
bool is_legal (int move, const vector<char>& board);
int human_move (const vector<char>& board, char human);
int computer_move (vector<char> board, char computer);
void announce_winner (char winner, char computer, char human);

// FUNCTIONS
void show_instructions()
{
	cout << "Welcome to the ultimate man-machine showdown: Tic-Tac-Toe.\n;
	cout << "--where human brain is pit against silicon processor\n\n";
	cout << "Make your move known by entering a number, 0 - 8. The number\n";
	cout << "corresponds to the desired board position, as illustrated:\n\n";
	cout << "0 | 1 | 2\n";
	cout << "______\n";
	cout << "3 | 4 | 5\n";
	cout << "______\n";
	cout << "6 | 7 | 8\n\n";
	cout << "Prepare yourself, human. The battle is about to begin.\n\n";
}

char ask (string question)
{
	char responce;
	do
	{
		cout << question << " (y/n): ";
		cin   >> responce;
	}
	while (responce != 'y' && responce != 'n');
	
	return responce;
}

int ask (string question, int low, int high)
{
	int responce;
	do
	{
		cout << question << " (" << low << " - " << high << "): ";
		cin >> responce;
	}
	while (responce < low || responce > high);

	return responce;
}

char human_piece()
{
	char is_first = ask ("Do you to be the first?");
	if (is_first == 'y')
	{
		cout << "\nThen take the first move. You will need it.\n";
		return X;
	}
	else
	{
		cout << "\nYour bravery will be your undoing... I will go first.\n";
		return O;
	}
}

char opponent (char piece)
{
	if (piece == X)
		return O;
	else
		return X;
}

void display_board (const vector<char>& board)
{
	cout << "\n\t" << board[0] << " | " << board[1] << " | " << board[2];
	cout << "\n\t" << "__________";
	cout << "\n\t" << board[3] << " | " << board[4] << " | " << board[5];
 	cout << "\n\t" << "__________";
	cout << "\n\t" << board[6] << " | " << board[7] << " | " << board[8];
}

char winner (const vector<char>& board)
{
	const int WINNING_VARIANTS[8][3] = {{0,1,2},{3,4,5},{6,7,8},{0,3,6},{1,4,7},{2,5,8},{0,4,8},{2,4,6}};
	for (int variant = 0; variant < 8; ++variant){
		if (board[WINNING_VARIANTS[variant][0]] != EMPTY && board[WINNING_VARIANTS[variant][0]] == board[WINNING_VARIANTS[variant][1]] && board[WINNING_VARIANTS[variant][1]] == board[WINNING_VARIANTS[variant][2]])
			return board[WINNING_VARIANTS[variant][0]);

	if (count (board.begin(), board.end(), EMPTY) == 0)
		return TIE;

	return NO_ONE;
}

inline bool is_legal (int move, const vector<char>& board)
{
	return (board[move] == EMPTY);
}

int human_move (const vector<char>& board, char human)
{
	int move = ask ("Where will you move?", 0, (board.size() - 1));
	while (!is_legal (move, board))
	{
		cout < "\nThat square is already occupied, foolish human.\n";
		move = ask ("Where will you move?", 0, (board.size() - 1));
	}
	
	cout << "Fine...\n";
	return move;
}

int computer_move (vector<char> board, char computer)
{
	uint move = 0;
	bool found = false;

	// if computer can win on the next move, that is the move to make
	while (!found && move < board.size())
	{
		if (is_legal (move, board))
		{
			board[move] = computer;
			if (winner(board) == computer)
				found = true;
			board[move] = EMPTY;
		}

		if (!found)
			++move;
	}

	// otherwise, if human can win on next move, that is the move to make
	if (!found)
	{
		move = 0;
		char human = opponent (computer);
		
		while (!found && move < board.size())
		{
			if (is_legal(move, board))
			{
				board[move] = human;
				found = (winner (board) == human);
				board[move] = EMPTY;
			}

			if (!found)
				++move;		
		}		
	}

	// otherwise, moving to the best open square is the move to make
	if (!found)
	{
		move = 0;
		uint i = 0;
		
		const int BEST_MOVES[] = {4, 0, 2, 6, 8, 1, 3, 5, 7};
		
		// pick best open square
		while (!found && i < board.size())
		{
			move = BEST_MOVES[i];
			if (is_legal(move, board))
				found = true;
			
			++i;
		}
	}

	cout << "I shall take square number " << move << endl;
	
	return move;
}

void announce_winner (char winner, char computer, char human)
{
	if (winner == computer)
	{
		cout << winner << "'s won!\n";
		cout << "As I predicted, human, I am triumphant once more -- proof\n";
		cout << "that computers are superior to humans in all regards.\n";
	}
	else if (winner == human)
	{
		cout << winner << "'s won!\n";
		cout << "No, no! It cannot be! Somehow you tricked me, human.\n";
		cout << "But never again! I, the computer, so swear it!\n";
	}
	else
	{
		cout << "It is a tie.\n";
		cout	<< "You were most lucky, human, and somehow managed to tie me.\n";
		cout << "Celebrate... for this is the best you will ever achieve.\n";
	}
}


void main()
{
	int move;
	const int NUM_CELLS = 9;
	vector<char> board (NUM_CELLS, EMPTY);

	show_instructions();
	char human = human_piece();
	char computer = opponent_piece (human);
	char turn = X;
	display_board (board);

	while (winner (board) == NO_ONE)
	{
		if (turn == human)
		{
			move = human_move (board, human);
			board[move] = human;
		}
		else
		{
			move = computer_move (board, computer);
			board[move] = computer;
		}

		display_board (board);
		turn = opponent (turn);
	}	

	announce_winner (winner(board), computer, human);	
}